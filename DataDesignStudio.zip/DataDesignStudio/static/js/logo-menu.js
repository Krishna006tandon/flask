document.addEventListener('DOMContentLoaded', function() {
    const logoCircle = document.querySelector('.logo-circle');
    const menuItems = document.querySelector('.menu-items');
    
    if (!logoCircle || !menuItems) return;
    
    // Menu items and their positions in a circle
    const menuLinks = [
        { icon: 'fa-home', url: '/', title: 'Home' },
        { icon: 'fa-search', url: '/search', title: 'Search' },
        { icon: 'fa-tag', url: '#', title: 'Categories', dropdown: true },
        { icon: 'fa-shopping-cart', url: '/cart', title: 'Cart' },
        { icon: 'fa-user', url: '/profile', title: 'Profile' }
    ];
    
    // Create menu items dynamically
    menuLinks.forEach((link, index) => {
        const menuItem = document.createElement('a');
        menuItem.className = 'menu-item';
        menuItem.href = link.url;
        menuItem.setAttribute('data-bs-toggle', 'tooltip');
        menuItem.setAttribute('data-bs-placement', 'bottom');
        menuItem.setAttribute('title', link.title);
        
        // Create icon
        const icon = document.createElement('i');
        icon.className = `fas ${link.icon}`;
        menuItem.appendChild(icon);
        
        // Set initial position (all centered on logo)
        menuItem.style.transform = 'translate(10px, 10px)';
        
        // If it's a dropdown category link
        if (link.dropdown) {
            menuItem.setAttribute('data-bs-toggle', 'dropdown');
            menuItem.setAttribute('aria-expanded', 'false');
            menuItem.href = '#';
            
            // Create dropdown menu
            const dropdownMenu = document.createElement('ul');
            dropdownMenu.className = 'dropdown-menu';
            
            // This would typically come from your categories data
            // For now, we'll add some placeholders
            const categories = [
                { id: 'electronics', name: 'Electronics' },
                { id: 'software', name: 'Software' },
                { id: 'design', name: 'Design Resources' },
                { id: 'tools', name: 'Developer Tools' },
                { id: 'games', name: 'Games' }
            ];
            
            categories.forEach(category => {
                const dropdownItem = document.createElement('li');
                const dropdownLink = document.createElement('a');
                dropdownLink.className = 'dropdown-item';
                dropdownLink.href = `/category/${category.id}`;
                dropdownLink.textContent = category.name;
                dropdownItem.appendChild(dropdownLink);
                dropdownMenu.appendChild(dropdownItem);
            });
            
            document.body.appendChild(dropdownMenu);
            
            // Initialize Bootstrap dropdown
            new bootstrap.Dropdown(menuItem);
        }
        
        menuItems.appendChild(menuItem);
    });
    
    // Get all menu items after creation
    const menuItemElements = document.querySelectorAll('.menu-item');
    
    // Toggle menu when logo is clicked
    let isOpen = false;
    
    logoCircle.addEventListener('click', function() {
        isOpen = !isOpen;
        
        if (isOpen) {
            menuItems.classList.add('visible');
            
            // Position menu items in a circle around the logo
            menuItemElements.forEach((item, index) => {
                const angle = (index * (360 / menuItemElements.length)) * (Math.PI / 180);
                const radius = 80; // Distance from center
                
                // Calculate position based on angle and radius
                const x = Math.cos(angle) * radius + 10; // +10 to center relative to parent
                const y = Math.sin(angle) * radius + 10;
                
                // Apply position with a slight delay for each item
                setTimeout(() => {
                    item.style.transform = `translate(${x}px, ${y}px)`;
                }, index * 100);
            });
            
            // Rotate logo when menu is open
            logoCircle.style.transform = 'rotate(45deg)';
        } else {
            // Return menu items to center
            menuItemElements.forEach((item, index) => {
                setTimeout(() => {
                    item.style.transform = 'translate(10px, 10px)';
                }, index * 100);
            });
            
            // Hide menu items after animation
            setTimeout(() => {
                menuItems.classList.remove('visible');
            }, menuItemElements.length * 100);
            
            // Reset logo rotation
            logoCircle.style.transform = 'rotate(0deg)';
        }
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (isOpen && !event.target.closest('.logo-menu-container')) {
            logoCircle.click(); // Use existing click handler to close
        }
    });
    
    // Initialize tooltips
    menuItemElements.forEach(item => {
        new bootstrap.Tooltip(item);
    });
});
