document.addEventListener('DOMContentLoaded', function() {
    // Initialize all tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize all popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Add fade-in animation to cards
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.classList.add('fade-in');
    });

    // Handle quantity input in cart
    const quantityInputs = document.querySelectorAll('.quantity-input');
    quantityInputs.forEach(input => {
        input.addEventListener('change', function() {
            const form = this.closest('form');
            if (form) {
                form.submit();
            }
        });
    });

    // Add to cart notification
    const addToCartBtns = document.querySelectorAll('.add-to-cart-btn');
    addToCartBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            // We'll let the default link behavior work, 
            // but we'll add a nice visual feedback
            const btnText = this.textContent;
            this.textContent = 'Added!';
            this.classList.add('btn-success');
            
            setTimeout(() => {
                this.textContent = btnText;
                this.classList.remove('btn-success');
            }, 1500);
        });
    });

    // Product sorting functionality
    const sortSelect = document.getElementById('sort-products');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            const productCards = document.querySelectorAll('.product-card');
            const productsContainer = document.querySelector('.products-container');
            const productsArray = Array.from(productCards);
            
            // Sort products based on selected value
            if (this.value === 'price-low') {
                productsArray.sort((a, b) => {
                    const priceA = parseFloat(a.dataset.price);
                    const priceB = parseFloat(b.dataset.price);
                    return priceA - priceB;
                });
            } else if (this.value === 'price-high') {
                productsArray.sort((a, b) => {
                    const priceA = parseFloat(a.dataset.price);
                    const priceB = parseFloat(b.dataset.price);
                    return priceB - priceA;
                });
            } else if (this.value === 'newest') {
                productsArray.sort((a, b) => {
                    const dateA = new Date(a.dataset.created);
                    const dateB = new Date(b.dataset.created);
                    return dateB - dateA;
                });
            }
            
            // Remove existing cards and append sorted ones
            productCards.forEach(card => card.remove());
            productsArray.forEach(card => productsContainer.appendChild(card));
        });
    }

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
});
