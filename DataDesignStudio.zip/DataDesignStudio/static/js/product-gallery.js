document.addEventListener('DOMContentLoaded', function() {
    const mainImage = document.getElementById('main-product-image');
    const thumbnails = document.querySelectorAll('.product-thumbnail');
    
    if (!mainImage || thumbnails.length === 0) return;
    
    // Set the first thumbnail as active initially
    thumbnails[0].classList.add('active');
    
    // Change main image when thumbnail is clicked
    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', function() {
            // Update main image source
            mainImage.src = this.src;
            
            // Remove active class from all thumbnails
            thumbnails.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked thumbnail
            this.classList.add('active');
            
            // Add a small zoom effect on the main image
            mainImage.style.transform = 'scale(1.03)';
            setTimeout(() => {
                mainImage.style.transform = 'scale(1)';
            }, 300);
        });
    });
    
    // Optional: Image slider/gallery functionality for mobile 
    let currentImageIndex = 0;
    
    // Create navigation arrows if more than one image
    if (thumbnails.length > 1) {
        const galleryContainer = document.querySelector('.product-gallery');
        
        // Create previous button
        const prevBtn = document.createElement('button');
        prevBtn.className = 'gallery-nav gallery-prev btn btn-sm';
        prevBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
        prevBtn.style.position = 'absolute';
        prevBtn.style.left = '10px';
        prevBtn.style.top = '50%';
        prevBtn.style.transform = 'translateY(-50%)';
        prevBtn.style.zIndex = '10';
        prevBtn.style.backgroundColor = 'rgba(0,0,0,0.5)';
        prevBtn.style.color = 'white';
        prevBtn.style.borderRadius = '50%';
        prevBtn.style.width = '40px';
        prevBtn.style.height = '40px';
        prevBtn.style.display = 'flex';
        prevBtn.style.alignItems = 'center';
        prevBtn.style.justifyContent = 'center';
        
        // Create next button
        const nextBtn = document.createElement('button');
        nextBtn.className = 'gallery-nav gallery-next btn btn-sm';
        nextBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
        nextBtn.style.position = 'absolute';
        nextBtn.style.right = '10px';
        nextBtn.style.top = '50%';
        nextBtn.style.transform = 'translateY(-50%)';
        nextBtn.style.zIndex = '10';
        nextBtn.style.backgroundColor = 'rgba(0,0,0,0.5)';
        nextBtn.style.color = 'white';
        nextBtn.style.borderRadius = '50%';
        nextBtn.style.width = '40px';
        nextBtn.style.height = '40px';
        nextBtn.style.display = 'flex';
        nextBtn.style.alignItems = 'center';
        nextBtn.style.justifyContent = 'center';
        
        galleryContainer.appendChild(prevBtn);
        galleryContainer.appendChild(nextBtn);
        
        // Navigation handlers
        prevBtn.addEventListener('click', function() {
            currentImageIndex = (currentImageIndex - 1 + thumbnails.length) % thumbnails.length;
            updateMainImage();
        });
        
        nextBtn.addEventListener('click', function() {
            currentImageIndex = (currentImageIndex + 1) % thumbnails.length;
            updateMainImage();
        });
        
        // Update main image based on current index
        function updateMainImage() {
            mainImage.src = thumbnails[currentImageIndex].src;
            
            // Update active thumbnail
            thumbnails.forEach(t => t.classList.remove('active'));
            thumbnails[currentImageIndex].classList.add('active');
            
            // Add slight animation effect
            mainImage.style.opacity = '0.8';
            mainImage.style.transform = 'scale(0.98)';
            
            setTimeout(() => {
                mainImage.style.opacity = '1';
                mainImage.style.transform = 'scale(1)';
            }, 200);
        }
        
        // Add swipe functionality for mobile
        let touchStartX = 0;
        let touchEndX = 0;
        
        mainImage.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
        });
        
        mainImage.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        });
        
        function handleSwipe() {
            if (touchEndX < touchStartX - 50) { // Swipe left
                nextBtn.click();
            } else if (touchEndX > touchStartX + 50) { // Swipe right
                prevBtn.click();
            }
        }
    }
});
